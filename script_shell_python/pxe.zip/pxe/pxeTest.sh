#!/usr/bin/bash
#使用root用户执行
echo "当前用户是："
whoami

if [ $('whoami') != 'root' ];then
  echo "请使用root用户执行！！!";
  sleep 1
  exit
fi

#ios镜像文件
read -p "请输入ios镜像文件绝对地址:" ios
#判断镜像文件是否存在
if [ ! -f $ios ];then
    echo "ios镜像文件找不到文件"
    exit
fi

#下载支持软件
sudo apt-get -y install dnsmasq
sudo apt-get -y install nfs-kernel-server
sudo apt-get -y install net-tools
sleep 2
#挂载目录
if [ -d /mnt/pxe ] ; then
    sudo umount /mnt/pxe
else
    sudo mkdir /mnt/pxe
fi
#判断nfs目录,执行NFS配置
if [ -d /var/nfs ] ; then
    sudo rm -rf /var/nfs/*
    sudo rm  /etc/exports
else
    sudo mkdir /var/nfs
fi
echo '/var/nfs *(ro,sync,no_subtree_check)' |sudo tee -a /etc/exports
sudo systemctl restart nfs-kernel-server
sleep 2
#判断TFTP跟目录
if [ -d /var/tftp ] ; then
    sudo rm -rf /var/tftp/*
else
    sudo mkdir /var/tftp
fi
sleep 2
#判断dnsmasq组
egrep "^dnsmasq" /etc/group >& /dev/null
if [ $? -ne 0 ]
then
    groupadd dnsmasq
else
    echo "dnsmasq存在"
fi
sleep 2

#配置网络
ipconf()
{
	ENP=$(ifconfig | grep "^en" | awk '{print$1}')
	nmcli connection delete pxe
	nmcli connection add con-name pxe type ethernet ifname ${ENP%%:*} autoconnect yes ip4 192.168.0.1/24 gw4 192.168.0.1
	sudo nmcli con up pxe
	sleep 2
}

#DNSMASQ配置
dnsMsaq()
{
    echo 'listen-address=192.168.0.1' >/etc/dnsmasq.conf
    echo 'dhcp-boot='$1 >>/etc/dnsmasq.conf
    echo 'interface='$2 >>/etc/dnsmasq.conf
    echo '
        bind-interfaces
        domain=pxe.local
        dhcp-range=192.168.0.50,192.168.0.150,1h
        dhcp-option=3,192.168.0.1
        dhcp-option=6,192.168.0.1
        server=114.114.114.114
        dhcp-option=28,192.168.0.255
        dhcp-option=42,0.0.0.0
        enable-tftp
        tftp-root=/var/tftp
    ' >>/etc/dnsmasq.conf
    sudo systemctl restart dnsmasq
    sleep 5
}

#判断iso架构
if [[ $ios == *"amd"* ]] ;then
    #AMD的nfs配置
	sudo apt-get -y install debian-installer-10-netboot-amd64
    sudo mkdir -p /var/nfs/amd64
    sudo mount $ios /mnt/pxe
    sudo cp -r /mnt/pxe/* /var/nfs/amd64
    sudo cp -r /mnt/pxe/.disk/ /var/nfs/amd64
    sudo chown -R root:root /var/nfs/
    find /var/nfs/amd64/ -type d -exec sudo chmod 755 {} \;
    ipconf
    #AMD的tftp配置
    sudo cp -r /usr/lib/debian-installer/images/10/amd64/text/debian-installer/ /var/tftp/
    AmdGrub="set menu_color_normal=white/black\nset menu_color_highlight=black/light-gray\ninsmod gzio\nmenuentry \"Install uos\" {\nset gfxpayload=keep\nlinux   /debian-installer/amd64/live/vmlinuz console=tty boot=live netboot=nfs nfsroot=192.168.0.1:/var/nfs/amd64/ components union=overlay locales=zh_CN.UTF-8 livecd-installer --\ninitrd  /debian-installer/amd64/live/initrd.lz\n}\nmenuentry \"Try uos without installing\" {\nset gfxpayload=keep\nlinux   /debian-installer/amd64/live/vmlinuz console=tty boot=live union=overlay quiet splash --\ninitrd  /debian-installer/amd64/live/initrd.lz}"
    #写入TFTP配置
    echo -e $AmdGrub >/var/tftp/debian-installer/amd64/grub/grub.cfg
    sudo cp -r /var/nfs/amd64/live/ /var/tftp/debian-installer/amd64/
    sudo cp /var/tftp/debian-installer/amd64/grubx64.efi  /var/tftp/
    sudo chown dnsmasq:dnsmasq /var/tftp -R 
    # DNSMASQ配置
    test1="/debian-installer/amd64/bootnetx64.efi"
    dnsMsaq $test1 ${ENP%%:*}
    sleep 5
    sudo journalctl -u dnsmasq -f

elif [[ $ios == *"arm"* ]] ;then
    #ARM的nfs配置
    sudo apt-get -y install debian-installer-10-netboot-arm64
    sudo mkdir /var/nfs/arm64
    sudo mount $ios /mnt/pxe
    sudo cp -r /mnt/pxe/* /var/nfs/arm64/
    sudo chown root:root /var/nfs/arm64 -R
    find /var/nfs/arm64 -type d -exec sudo chmod 755 {} \;
    ipconf
    #arm的TFTP配置
    sudo cp -r /usr/lib/debian-installer/images/10/arm64/text/debian-installer/ /var/tftp/
    ArmGrub="set menu_color_normal=white/black\n
    set menu_color_highlight=black/light-gray\n
    insmod gzio\n
    
    menuentry \"Install uos\" {\n
        set gfxpayload=keep\n
        linux   /debian-installer/arm64/live/vmlinuz console=tty boot=live netboot=nfs nfsroot=192.168.0.1:/var/nfs/arm64/ components union=overlay locales=zh_CN.UTF-8 livecd-installer --\n
        initrd  /debian-installer/arm64/live/initrd.img\n
    }\n
    menuentry \"Try uos without installing\" {\n
        set gfxpayload=keep\n
        linux   /debian-installer/arm64/live/vmlinuz console=tty boot=live union=overlay quiet splash --\n
        initrd  /debian-installer/arm64/live/initrd.img\n
    }"
    #写入TFTP配置
    echo -e $ArmGrub >/var/tftp/debian-installer/arm64/grub/grub.cfg
    sudo cp -r /var/nfs/arm64/live /var/tftp/debian-installer/arm64/
    sudo cp /var/tftp/debian-installer/arm64/grubaa64.efi /var/tftp/
    sudo chown dnsmasq:dnsmasq /var/tftp -R 
    # DNSMASQ配置
    test1="/debian-installer/arm64/bootnetaa64.efi,boothost,192.168.0.1"
    dnsMsaq $test1 ${ENP%%:*}
    sleep 5
    sudo journalctl -u dnsmasq -f
	
elif [[ $ios == *"mips"* ]] ;then
    #mips的nfs配置
    #sudo apt-get -y install debian-installer-10-netboot-mips64
    sudo mkdir -p /var/nfs/mips64el
    sudo mount $ios /mnt/pxe
    sudo cp -r /mnt/pxe/* /var/nfs/mips64el/
    sudo cp -r /mnt/pxe/.disk/ /var/nfs/mips64el/
    sudo chown -R root:root /var/nfs/mips64el/
    sudo find /var/nfs/mips64el/ -type d -exec sudo chmod 755 {} \;
    ipconf
    #tftp配置
    sudo mkdir -p /var/tftp/debian-installer/efi-mips64el
    sudo mkdir -p /var/tftp/debian-installer/live-mips64el
    sudo cp ./core.efi /var/tftp/debian-installer/efi-mips64el
    sudo cp -r /mnt/pxe/live/ /var/tftp/debian-installer/live-mips64el/
    sudo cp -r /mnt/pxe/boot/vmlinuz /var/tftp/debian-installer/live-mips64el/live
    sudo cp -r /mnt/pxe/boot/initrd.img /var/tftp/debian-installer/live-mips64el/live
    sudo cp -r /mnt/pxe/boot/initrd.img /var/tftp/
    sudo cp -r ./grub2/ /var/tftp/
    mipsGrub="set default=0\nset timeout=5\nsearch --no-floppy --set=root -l 'Fedora-MATE'\necho -e \"\\\nWelcome to UOS installer!\\\n\\\n\"\nmenuentry 'PXE Install UOS'{\necho 'Loading kernel ...'\nlinux /debian-installer/live-mips64el/live/vmlinuz root=/dev/nfs nfsroot=192.168.0.1:/var/nfs/mips64el rw console=tty livecd-installer locales=zh_CN.UTF-8 boot=live\necho 'Loading initrd ...'\ninitrd /debian-installer/live-mips64el/live/initrd.img\n}"
    echo -e $mipsGrub >/var/tftp/grub2/grub.cfg
    sudo chown dnsmasq:dnsmasq /var/tftp -R
    # DNSMASQ配置
    test1="/debian-installer/efi-mips64el/core.efi"
    dnsMsaq $test1 ${ENP%%:*}
    sleep 5
    sudo journalctl -u dnsmasq -f

fi




