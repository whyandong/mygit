#!/bin/bash
umount /mnt/pxe
rm -rf /mnt/pxe
apt --purge remove net-tools -y
apt --purge remove nfs-kernel-server -y
apt --purge remove dnsmasq -y
apt --purge remove debian-installer-10-netboot-arm64 -y
rm -rf /var/tftp
rm -rf /var/nfs
